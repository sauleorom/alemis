import axios from 'axios';

class AuthService {
  constructor() {
    this.apiUrl = 'https://192.168.1.80:44316/api'; 
  }

  async register(username, password) {
    try {
      const response = await axios.post(`${this.apiUrl}/Users/register`, {
        username,
        password,
      });
      return response.data; 
    } catch (error) {
      throw new Error(error.response.data.message || 'Error en el registro');
    }
  }

  async login(username, password) {
    try {
      const response = await axios.post(`${this.apiUrl}/login`, {
        username,
        password,
      });
      localStorage.setItem('token', response.data.token); 
      return response.data.user; 
    } catch (error) {
      throw new Error(error.response.data.message || 'Error en la autenticación');
    }
  }

  async logout() {
    localStorage.removeItem('token');
  }

}

const authService = new AuthService();
export default authService;

