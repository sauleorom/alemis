import axios from 'axios';

class AuthService {
  constructor() {
    this.apiUrl = 'https://localhost:7000/api'; 
  }

  async journal(username, password) {
    try {
      const response = await axios.post(`${this.apiUrl}/journal`, {
        username,
        password,
      });
      return response.data; 
    } catch (error) {
      throw new Error(error.response.data.message || 'Error en el registro');
    }
  }

  async suscription(username, password) {
    try {
      const response = await axios.post(`${this.apiUrl}/suscription`, {
        username,
        password,
      });
      localStorage.setItem('token', response.data.token); 
      return response.data.user; 
    } catch (error) {
      throw new Error(error.response.data.message || 'Error en la autenticación');
    }
  }

  async logout() {
    localStorage.removeItem('token');
  }

}

const authService = new AuthService();
export default authService;

