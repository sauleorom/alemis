import './App.css';
import { LoginComponent , RegisterComponent , SubsComponent , NotificationProvider } from './Components';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

const App = () => {
  return (
    <Router>
      <NotificationProvider>
        {(notify) => (
          <>
            <Routes>
              <Route path="/" element={<LoginComponent notify={notify} />} />
              <Route path="/register" element={<RegisterComponent notify={notify} />} />
              <Route path="/home" element={<SubsComponent notify={notify} />} />
            </Routes>
          </>
        )}
      </NotificationProvider>
    </Router>
  );
};

export default App;
