import  { useState } from 'react';

// Ejemplo de datos de investigadores
const researchersData = [
  {
    id: 1,
    name: 'Dr. Jane Doe',
    journal: 'Journal of Research',
    publications: [
      'Publication 1 - 2023',
      'Publication 2 - 2022',
      'Publication 3 - 2021',
    ],
  },
  {
    id: 2,
    name: 'Dr. John Smith',
    journal: 'Journal of Science',
    publications: [
      'Publication A - 2023',
      'Publication B - 2022',
      'Publication C - 2021',
    ],
  },
];

const SubsComponent = () => {
  const [subscribedResearchers, setSubscribedResearchers] = useState([]);

  const handleSubscribe = (researcher) => {
    if (!subscribedResearchers.includes(researcher.id)) {
      setSubscribedResearchers([...subscribedResearchers, researcher.id]);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Sistema de Suscripción a Investigadores</h2>
      <div className="list-group">
        {researchersData.map((researcher) => (
          <div key={researcher.id} className="list-group-item">
            <h5>{researcher.name}</h5>
            <p>{researcher.journal}</p>
            <button
              className="btn btn-primary"
              onClick={() => handleSubscribe(researcher)}
              disabled={subscribedResearchers.includes(researcher.id)}
            >
              {subscribedResearchers.includes(researcher.id) ? 'Suscrito' : 'Suscribirse'}
            </button>
            <h6 className="mt-2">Publicaciones:</h6>
            <ul>
              {researcher.publications.map((publication, index) => (
                <li key={index}>{publication}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SubsComponent;
