import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authService } from '../Services';
import PropTypes from 'prop-types';

const LoginComponent = ({ notify }) => {
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const loggedInUser = await authService.login(user, password);
      notify(`Bienvenido ${loggedInUser}`, 'success'); // Usar notify correctamente
      navigate('/view');

      navigate('/view'); // Ejemplo de redirección después de iniciar sesión
    } catch (error) {
      notify(error.message, 'danger');
    }
  };

  const handleRegister = () => {
    navigate('/register'); // Navega a la página de registro
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-12 col-lg-12 col-sm-12">
          <div className="card shadow-sm">
            <div className="card-body">
              <h2 className="card-title text-center mb-4">Inicia Sesion</h2>
              <form onSubmit={handleSubmit}>
                <div className="form-floating mb-3">
                  <input
                    type="text"
                    className="form-control"
                    id="user"
                    placeholder="Usuario"
                    value={user}
                    onChange={(e) => setUser(e.target.value)}
                    required
                  />
                  <label htmlFor="user">Usuario</label>
                </div>

                <div className="form-floating mb-3">
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    placeholder="contraseña"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <label htmlFor="password">Contraseña</label>
                </div>

                <button type="submit" className="btn btn-dark w-100">
                  Iniciar Sesion
                </button>
                <button className="mt-2 btn btn-outline-dark w-100" onClick={handleRegister}>
                  No tienes Cuenta ?
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

LoginComponent.propTypes = {
  notify: PropTypes.func.isRequired, // notify debe ser una función y es requerida
};

export default LoginComponent;
